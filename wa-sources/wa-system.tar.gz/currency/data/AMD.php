<?php

return array(
    'code' => 'AMD',
    'sign' => 'dram',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Armenian dram',
    'name' => array(
        array('dram', 'drams'),
    ),
    'frac_name' => array(
    )
);