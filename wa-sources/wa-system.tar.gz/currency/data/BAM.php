<?php

return array(
    'code' => 'BAM',
    'sign' => 'KM',
    'sign_position' => 0,
    'sign_delim' => ' ',
    'title' => 'Bosnia and Herzegovina convertible mark',
    'name' => array(
        array('mark', 'marks'),
        array('convertible mark', 'convertible marks'),
    ),
    'frac_name' => array(
        'fening',
    )
);