<?php

return array(
    'code' => 'LTL',
    'sign' => 'Lt',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Lithuanian litas',
    'name' => array(
        array('litas', 'litai'),
    ),
    'frac_name' => array(
        array('centas', 'centai'),
    )
);