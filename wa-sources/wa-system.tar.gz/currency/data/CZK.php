<?php

return array(
    'code' => 'CZK',
    'sign' => 'Kč',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Czech koruna',
    'name' => array(
        array('koruna', 'korunas'),
    ),
    'frac_name' => array(
        array('haler', 'halers'),
    )
);