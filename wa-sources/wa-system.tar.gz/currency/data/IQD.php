<?php

return array(
    'code' => 'IQD',
    'sign' => 'ع.د',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Iraqi dinar',
    'name' => array(
        array('dinar', 'dinars'),
    ),
    'frac_name' => array(
        'fils',
    )
);