<?php

return array(
    'code' => 'KZT',
    'sign' => 'T',
    'title' => 'Kazakhstani tenge',
    'name' => array(
        array('tenge', 'tenges'),
    ),
    'frac_name' => array(
	  array('tïın', 'tïıns'),
    )
);