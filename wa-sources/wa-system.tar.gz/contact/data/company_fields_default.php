<?php
return array (
  'name' => array (),
  'company' => array (
        'required' => true,
      ),
  'email' => array (),
  'about' => array (),
  'phone' => array (),
  'address' => array (),
  'url' => array (),
  'categories' => array (),
);
// EOF