<?php
return array (
  'name' => array (),
  'title' => array (),
  'firstname' => array (),
  'middlename' => array (),
  'lastname' => array (),
  'sex' => array (),
  'company' => array (),
  'email' => array (),
  'phone' => array (),
  'im' => array (),
  'address' => array (),
  'url' => array (),
  'birthday' => array (),
  'locale' => array (),
  'timezone' => array (),
  'about' => array (),
  'categories' => array (),
);
// EOF