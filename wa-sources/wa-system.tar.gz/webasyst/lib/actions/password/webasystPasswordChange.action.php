<?php

class webasystPasswordChangeAction extends waViewAction
{
    public function execute()
    {

    }
}  