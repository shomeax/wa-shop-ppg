<?php 

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'icon' => 'img/webasyst.gif',
    'analytics' => true,
    'version' => '1.1.1',
    'critical'=>'1.1.1',
    'vendor' => 'webasyst',
);
