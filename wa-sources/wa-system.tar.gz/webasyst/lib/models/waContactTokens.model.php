<?php 

class waContactTokensModel extends waModel
{
    protected $id = 'token';
    protected $table = 'wa_contact_tokens';
    
}