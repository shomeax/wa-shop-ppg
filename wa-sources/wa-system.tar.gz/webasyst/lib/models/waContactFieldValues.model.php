<?php

class waContactFieldValuesModel extends waModel
{
    protected $table = 'wa_contact_field_values';
}
