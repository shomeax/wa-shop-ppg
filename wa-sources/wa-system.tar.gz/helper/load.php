<?php

$dir = dirname(__FILE__);
include $dir."/misc.php";
include $dir."/view.php";
include $dir."/datetime.php";
include $dir."/currency.php";
