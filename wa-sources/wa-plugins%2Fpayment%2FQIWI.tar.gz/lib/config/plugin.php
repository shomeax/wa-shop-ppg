<?php
return array(
    'name'        => 'QIWI',
    'description' => 'QIWI',
    'vendor'      => 'webasyst',
    'version'     => '1.0.0',
    'type'        => waPayment::TYPE_ONLINE,
);
