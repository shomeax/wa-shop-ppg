<?php
return array(
    'name'        => /*_wp*/('Courier'),
    'description' => /*_wp*/('Courier shipping module. Shipping rate is calculated based on the shipping region, and either order total amount or order total weight.'),
    'icon'        => 'img/courier16.png',
    'logo'        => 'img/courier.png',
    'version'     => '1.0.0',
    'vendor'      => 'webasyst',
);
