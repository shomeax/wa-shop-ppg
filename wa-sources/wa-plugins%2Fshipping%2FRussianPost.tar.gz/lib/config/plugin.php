<?php
return array(
    'name'        => 'Почта России',
    'description' => 'Расчет стоимости доставки по алгоритму, опубликованному <a href="http://www.russianpost.ru/rp/servise/ru/home/postuslug/bookpostandparcel/parcelltariff">на сайте Почты России</a> для отправления посылок.',
    'icon'        => 'img/RussianPost16.png',
    'logo'        => 'img/RussianPost.png',
    'version'     => '1.0.0',
    'vendor'      => 'webasyst',
);
