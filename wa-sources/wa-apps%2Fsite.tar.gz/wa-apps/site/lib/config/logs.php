<?php

return array(
    'page_add' => array(),
    'page_edit' => array(),
    'page_delete' => array(),
    'page_move' => array(),

    'template_add' => array(),
    'template_edit' => array(),
    'template_delete' => array(),

    'theme_upload' => array(),
    'theme_download' => array(),
    'theme_delete' => array(),
    'theme_reset' => array(),
    'theme_duplicate' => array(),
    'theme_rename' => array(),

    'site_add' => array(),
    'site_edit' => array(),
    'site_delete' => array(),

    'file_upload' => array(),
    'file_delete' => array(),

    'block_add' => array(),
    'block_edit' => array(),
    'block_delete' => array(),

    'route_add' => array(),
    'route_edit' => array(),
    'route_delete' => array(),
);