<?php 

class sitePageParamsModel extends waPageParamsModel
{
    protected $table = 'site_page_params';
}