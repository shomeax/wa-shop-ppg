<?php 
return array(
	'name' => 'Stickies',
	'prefix' => 'stickies',
	'img' => 'img/stickies.png',
	'rights' => true,
	'mobile' => true,
	'version' => '1.0.0',
	'critical'=>'1.0.0', 
	'vendor' => 'webasyst',
);
