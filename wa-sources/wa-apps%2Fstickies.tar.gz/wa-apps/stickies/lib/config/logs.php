<?php

return array(
	'board_add' => array(),
	'board_edit' => array(),
	'board_delete' => array(),
	'sticky_add' => array(),
	'sticky_edit' => array(),
	'sticky_resize' => array(),
	'sticky_move_to_board' => array(),
	'sticky_delete' => array(),
	'sticky_move' => array(),
);