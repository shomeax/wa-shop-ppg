<?php 

$sheet_model = new stickiesSheetModel();
$sheet_model->create(_w('My stickies'), null, false);