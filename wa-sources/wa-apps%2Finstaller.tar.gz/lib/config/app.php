<?php 
return array(
	'name' => 'Installer',
	'description'=>'Provides configuration management tools to your setup',
	'prefix' => 'installer',
	'img' => 'img/installer.png',
	'mobile' => false,
	'version' => '1.1.1',
	'critical'=>'1.1.1',
	'system'=>true,
	'vendor'=>'webasyst',
);
