<?php
return array(
    'name' => /*_wp*/('Cash'),
    'description' => /*_wp*/('Pay in cash upon receipt'),
    'vendor' => 'webasyst',
    'version' => '1.0.0',
    'type' => waPayment::TYPE_MANUAL,
);
