<?php

return array(
    'en_US',
    'ru_RU',
);
