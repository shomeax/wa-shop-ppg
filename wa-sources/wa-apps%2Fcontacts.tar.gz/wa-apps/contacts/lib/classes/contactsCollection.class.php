<?php

class contactsCollection extends waContactsCollection
{
    protected $options = array(
            'check_rights' => true
    );	
}