<?php

return array(
	'name' => 'Contacts',
	'img' => 'img/contacts.png',
	'rights' => true,
	'analytics' => true,
	'version'=>'1.0.3',
	'critical'=>'1.0.0',
	'vendor' => 'webasyst',
	'system' => true,
);