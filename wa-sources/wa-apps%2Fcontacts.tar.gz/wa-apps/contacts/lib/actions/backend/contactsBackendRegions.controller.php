<?php

class contactsBackendRegionsController extends webasystBackendRegionsController
{
    // Nothing to do!
}

