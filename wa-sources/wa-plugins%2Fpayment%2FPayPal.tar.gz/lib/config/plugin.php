<?php
return array(
    'name' => /*_wp*/('PayPal'),
    'description' => /*_wp*/('PayPal Payments Standard Integration'),
    'vendor' => 'webasyst',
    'version' => '1.0.0',
    'type' => waPayment::TYPE_ONLINE,
);
