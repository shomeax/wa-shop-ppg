<?php
return array(
    'email' => array(
        'value' => '',
        'title' => /*_wp*/('Merchant email'),
        'description' => /*_wp*/('Merchant email'),
        'control_type' => 'input',
    ),
    'sandbox' => array(
        'value' => '',
        'title' => /*_wp*/('Sandbox'),
        'description' => /*_wp*/('Use this mode for test purpose'),
        'control_type' => 'checkbox',
    ),
);
